package com.showtime.dto;

import java.time.LocalDateTime;

public class ShowDetailsDTO {
    private Long id;
    private MovieDTO movie;
    private TheatreDTO theatre;
    private LocalDateTime showTime;
    private int availableSeats;
    private int totalSeats;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public MovieDTO getMovie() {
		return movie;
	}
	public void setMovie(MovieDTO movie) {
		this.movie = movie;
	}
	public TheatreDTO getTheatre() {
		return theatre;
	}
	public void setTheatre(TheatreDTO theatre) {
		this.theatre = theatre;
	}
	public LocalDateTime getShowTime() {
		return showTime;
	}
	public void setShowTime(LocalDateTime showTime) {
		this.showTime = showTime;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	public int getTotalSeats() {
		return totalSeats;
	}
	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}

    // Getters and setters
    
}
