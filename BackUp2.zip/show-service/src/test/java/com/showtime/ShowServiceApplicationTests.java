package com.showtime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShowServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
