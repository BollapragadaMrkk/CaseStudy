package com.payment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.payment.entity.Ewallet;
import com.payment.entity.Statement;
import com.payment.service.EwalletServiceImpl;

import java.util.List;

@RestController
@RequestMapping("/wallet")
public class EwalletController {

    @Autowired
    private EwalletServiceImpl ewalletService;

    @GetMapping("/all")
    public ResponseEntity<List<Ewallet>> getAllWallets() {
        return ResponseEntity.ok(ewalletService.getWallets());
    }

    @PostMapping("/add")
    public ResponseEntity<Ewallet> addWallet(@RequestBody Ewallet ewallet) {
        return ResponseEntity.ok(ewalletService.addWallet(ewallet));
    }

    @PutMapping("/addMoney/{walletId}")
    public ResponseEntity<Void> addMoney(@PathVariable int walletId, @RequestBody double amount) {
        Ewallet ewallet = ewalletService.getById(walletId);
        if (ewallet != null) {
            ewalletService.addMoney(walletId, amount);
            return ResponseEntity.ok().build();
        }
        return ResponseEntity.notFound().build();
    }

    @PutMapping("/update/{userId}")
    public ResponseEntity<Void> updateWalletByUserId(@PathVariable Integer userId,@RequestParam Double amount,@RequestParam String transactionType,@RequestParam String transactionRemarks) {
        ewalletService.updateWallet(userId, amount, transactionRemarks, transactionType);
        return ResponseEntity.ok().build();
    }
//    @PutMapping("/update/{userId}")
//    public ResponseEntity<Void> updateWalletByUserId(
//            @PathVariable Integer userId,
//            @RequestParam Double amount,
//            @RequestParam String transactionType,
//            @RequestParam String transactionRemarks,
//            @RequestParam Integer orderId) { // Add orderId as a request parameter
//            
//        ewalletService.updateWallet(userId, amount, transactionRemarks, transactionType, orderId); // Pass the orderId to the service method
//        return ResponseEntity.ok().build();
//    }


    @GetMapping("/id/{walletId}")
    public ResponseEntity<Ewallet> getWalletById(@PathVariable int walletId) {
        Ewallet ewallet = ewalletService.getById(walletId);
        return ewallet != null ? ResponseEntity.ok(ewallet) : ResponseEntity.notFound().build();
    }
    
    @GetMapping("/balance/{walletId}")
    public double getcurrentBalanceByUserId(@PathVariable int walletId) throws Exception {
        double balance= (double)ewalletService.getBalance(walletId);
        return balance;
    }

    @GetMapping("/statements/all")
    public ResponseEntity<List<Statement>> getAllStatements() {
        return ResponseEntity.ok(ewalletService.getStatemants());
    }

    @GetMapping("/statements/{walletId}")
    public ResponseEntity<List<Statement>> getStatementsByWalletId(@PathVariable int walletId) {
        return ResponseEntity.ok(ewalletService.getStatemantsById(walletId));
    }

    @DeleteMapping("/delete/{walletId}")
    public ResponseEntity<Void> deleteWallet(@PathVariable int walletId) {
        ewalletService.deleteById(walletId);
        return ResponseEntity.ok().build();
    }
//  razorpay method
  @PostMapping("/create-payment-link")
  public ResponseEntity<String> createPaymentLink(
          @RequestParam int walletId,
          @RequestParam Double amount
          ) {

      String paymentLink = ewalletService.createPaymentLink(walletId , amount);
      return ResponseEntity.ok(paymentLink);
  }
  
  @GetMapping("/callback")
  public String paymentCallback(@RequestParam String razorpay_payment_id,
                                @RequestParam String razorpay_payment_link_id,
                                @RequestParam String razorpay_payment_link_status,
                                @RequestParam String razorpay_payment_link_reference_id) {

      if (!"paid".equals(razorpay_payment_link_status)) {
          return "Payment failed.";
      }

      String[] referenceParts = razorpay_payment_link_reference_id.split("_");
      if (referenceParts.length < 2) {
          return "Invalid reference ID format.";
      }
//      int userId = Integer.parseInt(referenceParts[0]);
//      double amount = Double.parseDouble(referenceParts[1]);
//      WalletAdder walletAdder = new WalletAdder(userId, amount, "Payment via Razorpay");
//      ewalletService.addMoney(walletAdder);
//
//      return "Payment successful! Wallet updated.";
      try {
          int walletId = Integer.parseInt(referenceParts[0]);
          double amount = Double.parseDouble(referenceParts[1]);

          // 🔹 Add money to wallet
          ewalletService.addMoney(walletId, amount);

          return "Payment successful! Wallet updated.";
      } catch (NumberFormatException e) {
          return "Invalid data in reference ID.";
      }
  }
}
