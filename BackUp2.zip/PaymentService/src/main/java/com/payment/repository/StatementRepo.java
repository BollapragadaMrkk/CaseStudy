package com.payment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.payment.entity.Statement;

public interface StatementRepo extends JpaRepository<Statement, Integer>{
	List<Statement> findByEwallet_WalletId(int walletId);
}
