package com.payment.service;

import java.util.List;

import com.payment.entity.Ewallet;
import com.payment.entity.Statement;

public interface EwalletService {
	List<Ewallet> getWallets();
	Ewallet addWallet(Ewallet ewallet);
	void addMoney(int walletId, double amount);
	Ewallet getById(int walletId);
	List<Statement> getStatemants();
	List<Statement> getStatemantsById(int walletId);
	void deleteById(int walletId);
	void updateWallet(Integer profileId, Double amount, String transactionRemarks, String transactionType);
	String createPaymentLink(int userId, Double amount);
//	void updateWallet(Integer profileId, Double amount, String transactionRemarks, String transactionType, Integer orderId);
}
