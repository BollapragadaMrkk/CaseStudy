package com.payment.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.payment.entity.Ewallet;
import com.payment.entity.Statement;
import com.payment.repository.EwalletRepository;
import com.payment.repository.StatementRepo;
import com.razorpay.PaymentLink;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;

@Service
public class EwalletServiceImpl implements EwalletService {
	
    @Autowired
    private EwalletRepository ewalletRepository;
    
    @Autowired
    private StatementRepo statementRepository;

    @Override
    public List<Ewallet> getWallets() {
        return ewalletRepository.findAll();
    }

    @Override
    public Ewallet addWallet(Ewallet ewallet) {	
        return ewalletRepository.save(ewallet);
    }

    @Override
    public void addMoney(int walletId, double amount) {
    	Ewallet ewallet = getById(walletId);
    	ewallet.setCurrentBalance(ewallet.getCurrentBalance() + amount);
        ewalletRepository.save(ewallet);
        Statement statement = new Statement();
        statement.setAmount(amount);
        statement.setTransactionType("CREDIT");
        statement.setDatetime(LocalDateTime.now());
        statement.setTransactionRemarks("Amount added to wallet");

        statementRepository.save(statement);
    }

    @Override
    public void updateWallet(Integer userId, Double amount, String transactionRemarks, String transactionType){
        Ewallet wallet = getWalletByUserId(userId);
        if (transactionType.equals("Debit") && wallet.getCurrentBalance() >= amount) {
            wallet.setCurrentBalance(wallet.getCurrentBalance() - amount);
        } else if (transactionType.equals("Credit")) {
            wallet.setCurrentBalance((wallet.getCurrentBalance() + amount));
        }
        if (wallet.getStatement()==null){
            wallet.setStatement(getStatemants());
        }
        wallet.getStatement().add(new Statement(
        	    null, 
        	    transactionType,  
        	    amount, 
        	    LocalDateTime.now(),  
        	    wallet, 
        	    transactionRemarks
        	));
        System.out.println("Updating wallet for userId = " + userId + ", amount = " + amount);
        ewalletRepository.save(wallet);
    }



    private Ewallet getWalletByUserId(Integer userId) {
        return ewalletRepository.findByUserId(userId);
    }

	@Override
    public Ewallet getById(int walletId) {
        return ewalletRepository.findById(walletId).orElse(null);
    }
	
	public Double getBalance(int walletId) throws Exception {
	    Optional<Ewallet> walletOptional = ewalletRepository.findById(walletId);
	    if (walletOptional.isPresent()) {
	        return walletOptional.get().getCurrentBalance();
	    } else {
	        throw new Exception("Wallet not found for walletId: " + walletId);
	    }
	}

    @Override
    public List<Statement> getStatemants() {
        return statementRepository.findAll();
    }

    @Override
    public List<Statement> getStatemantsById(int walletId) {
        return statementRepository.findByEwallet_WalletId(walletId);
    }

    @Override
    public void deleteById(int walletId) {
        ewalletRepository.deleteById(walletId);
        statementRepository.deleteById(walletId);
    }
    
//    @Override
//    public String createPaymentLink(int userId, Double amount) {
//    	
//    	String keyId="rzp_test_ZCxFKPgSpv6kQ2";
//    	String keySecret = "GqXc5GjVPhPHjUYjdcaqHiTS";
//    	String callbackUrl = "http://localhost:8086/wallet/callback";
//    		
//        try {
//            RazorpayClient razorpayClient = new RazorpayClient(keyId, keySecret);
//
//            String referenceId = (userId + "_" + amount + "_" + UUID.randomUUID()).substring(0,40);
//            System.out.println(userId + "" + amount + "" + UUID.randomUUID().toString());
//
//            JSONObject paymentLinkRequest = new JSONObject();
//            paymentLinkRequest.put("amount", amount * 100); 
//            paymentLinkRequest.put("currency", "INR");
//            paymentLinkRequest.put("expire_by", (System.currentTimeMillis() / 1000) + 3600); 
//            paymentLinkRequest.put("callback_url", callbackUrl);
//            paymentLinkRequest.put("callback_method", "get");
//            paymentLinkRequest.put("reference_id", referenceId); 
//
//            PaymentLink paymentLink = razorpayClient.paymentLink.create(paymentLinkRequest);
//            return paymentLink.get("short_url"); 
//        } catch (RazorpayException e) {
//            e.printStackTrace();
//            return "Error creating payment link";
//            }
//    }
    @Override
    public String createPaymentLink(int walletId, Double amount) {

        String keyId = "rzp_test_mWP56Xw4r7vqCR";
        String keySecret = "ZbWKlhF31AdxHVooAeKQa6RZ";
        String callbackUrl = "http://localhost:8086/wallet/callback";

        try {
            RazorpayClient razorpayClient = new RazorpayClient(keyId, keySecret);

            // Reference format: walletId_amount_UUID (max 40 chars)
            String referenceId = (walletId + "_" + amount + "_" + UUID.randomUUID())
                                    .substring(0, 40);

            JSONObject paymentLinkRequest = new JSONObject();
            paymentLinkRequest.put("amount", amount * 100); 
            paymentLinkRequest.put("currency", "INR");
            paymentLinkRequest.put("expire_by", (System.currentTimeMillis() / 1000) + 3600);
            paymentLinkRequest.put("callback_url", callbackUrl);
            paymentLinkRequest.put("callback_method", "get");
            paymentLinkRequest.put("reference_id", referenceId);

            PaymentLink paymentLink = razorpayClient.paymentLink.create(paymentLinkRequest);
            return paymentLink.get("short_url");

        } catch (RazorpayException e) {
            e.printStackTrace();
            return "Error creating payment link";
        }
    }

}
