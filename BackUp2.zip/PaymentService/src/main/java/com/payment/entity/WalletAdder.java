//package com.wallet.WalletService.entity;
//
//public class WalletAdder {
//	private int userId;
//	private Double ammount;
//	private String remarks;
//	public WalletAdder(int userId, Double ammount, String remarks) {
//		super();
//		this.userId = userId;
//		this.ammount = ammount;
//		this.remarks = remarks;
//	}
//	public WalletAdder() {
//		super();
//		// TODO Auto-generated constructor stub
//	}
//	public int getProfileId() {
//		return userId;
//	}
//	public void setProfileId(int profileId) {
//		this.userId = profileId;
//	}
//	public Double getAmmount() {
//		return ammount;
//	}
//	public void setAmmount(Double ammount) {
//		this.ammount = ammount;
//	}
//	public String getRemarks() {
//		return remarks;
//	}
//	public void setRemarks(String remarks) {
//		this.remarks = remarks;
//	}
//}



