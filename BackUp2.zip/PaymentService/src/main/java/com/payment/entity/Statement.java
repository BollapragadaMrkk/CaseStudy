package com.payment.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table(name = "wallet_statements")
public class Statement {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer statementId;
	private String transactionType;
	private double amount;
	private LocalDateTime datetime;
//	private Integer orderId;
	private String transactionRemarks;
	@ManyToOne
    @JoinColumn(name = "wallet_id", nullable = false) // This links statements to a wallet
    private Ewallet ewallet;
	public Integer getStatementId() {
		return statementId;
	}
	public void setStatementId(Integer statementId) {
		this.statementId = statementId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public LocalDateTime getDatetime() {
		return datetime;
	}
	public void setDatetime(LocalDateTime datetime) {
		this.datetime = datetime;
	}
//	public int getOrderId() {
//		return orderId;
//	}
//	public void setOrderId(int orderId) {
//		this.orderId = orderId;
//	}
	public String getTransactionRemarks() {
		return transactionRemarks;
	}
	public void setTransactionRemarks(String transactionRemarks) {
		this.transactionRemarks = transactionRemarks;
	}
//	public Statement(Integer statementId, String transactionType, double amount, LocalDateTime datetime, Integer orderId,
//			String transactionRemarks) {
//		super();
//		this.statementId = statementId;
//		this.transactionType = transactionType;
//		this.amount = amount;
//		this.datetime = datetime;
//		this.orderId = orderId;
//		this.transactionRemarks = transactionRemarks;
//	}
	public Statement(Integer statementId, String transactionType, double amount, LocalDateTime datetime,String transactionRemarks) {
		super();
		this.statementId = statementId;
		this.transactionType = transactionType;
		this.amount = amount;
		this.datetime = datetime;
		this.transactionRemarks = transactionRemarks;
	}
	public Statement() {
		super();
	}
	public Statement(int walletId, double amount2, String transactionType2) {
		
	}
//	public Statement(Object statementId, String transactionType, Double amount, LocalDateTime now, Ewallet wallet,
//	        String transactionRemarks) {
//	    this.statementId = (Integer) statementId;
//	    this.transactionType = transactionType;
//	    this.amount = amount;
//	    this.datetime = now;
//	    this.transactionRemarks = transactionRemarks;
//	    this.ewallet = wallet;
//	}
//	public Statement(Integer statementId, String transactionType, Double amount, LocalDateTime datetime, 
//            Ewallet ewallet, String transactionRemarks, Integer orderId) {
//		this.statementId = statementId;
//		this.transactionType = transactionType;
//		this.amount = amount;
//		this.datetime = datetime;
//		this.transactionRemarks = transactionRemarks;
//		this.ewallet = ewallet;
//		this.orderId = orderId;  // Set the orderId here
//	}
	public Statement(Integer statementId, String transactionType, Double amount, LocalDateTime datetime, 
            Ewallet ewallet, String transactionRemarks) {
		this.statementId = statementId;
		this.transactionType = transactionType;
		this.amount = amount;
		this.datetime = datetime;
		this.transactionRemarks = transactionRemarks;
		this.ewallet = ewallet;
	}
	public Ewallet getEwallet() {
		return ewallet;
	}
	public void setEwallet(Ewallet ewallet) {
		this.ewallet=ewallet;
	}
}
