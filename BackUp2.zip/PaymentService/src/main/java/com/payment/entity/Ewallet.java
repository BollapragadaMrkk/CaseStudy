package com.payment.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.OneToMany;

@Entity
@Table(name = "ewallet")
public class Ewallet {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int walletId;
	private double currentBalance;
	private int userId;
	@OneToMany(mappedBy = "ewallet", cascade = CascadeType.ALL)
    private List<Statement> statement = new ArrayList<>();
	public int getWalletId() {
		return walletId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public void setWalletId(int walletId) {
		this.walletId = walletId;
	}
	public double getCurrentBalance() {
		return currentBalance;
	}
	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}
	public List<Statement> getStatement(){
		return statement;
	}
	public void setStatement(List<Statement> statement) {
		this.statement=statement;
	}
}
