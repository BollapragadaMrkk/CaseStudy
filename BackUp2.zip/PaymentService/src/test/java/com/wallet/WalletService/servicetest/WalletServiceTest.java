package com.wallet.WalletService.servicetest;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.payment.entity.Ewallet;
import com.payment.entity.Statement;
import com.payment.repository.EwalletRepository;
import com.payment.repository.StatementRepo;
import com.payment.service.EwalletServiceImpl;

class EwalletServiceImplTest {

    @Mock
    private EwalletRepository ewalletRepository;

    @Mock
    private StatementRepo statementRepository;

    @InjectMocks
    private EwalletServiceImpl ewalletService;

    private Ewallet wallet;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        wallet = new Ewallet();
        wallet.setWalletId(1);
        wallet.setUserId(101);
        wallet.setCurrentBalance(1000.0);
    }

    @Test
    void testGetWallets() {
        when(ewalletRepository.findAll()).thenReturn(Arrays.asList(wallet));
        List<Ewallet> wallets = ewalletService.getWallets();
        assertEquals(1, wallets.size());
    }

    @Test
    void testAddWallet() {
        when(ewalletRepository.save(wallet)).thenReturn(wallet);
        Ewallet result = ewalletService.addWallet(wallet);
        assertNotNull(result);
        assertEquals(wallet.getWalletId(), result.getWalletId());
    }

    @Test
    void testAddMoney() {
        when(ewalletRepository.findById(1)).thenReturn(Optional.of(wallet));
        when(ewalletRepository.save(any(Ewallet.class))).thenReturn(wallet);
        when(statementRepository.save(any(Statement.class))).thenReturn(new Statement());

        ewalletService.addMoney(1, 500.0);

        verify(ewalletRepository).save(wallet);
        verify(statementRepository).save(any(Statement.class));
        assertEquals(1500.0, wallet.getCurrentBalance());
    }

    @Test
    void testUpdateWallet_Credit() {
        when(ewalletRepository.findByUserId(101)).thenReturn(wallet);
        when(ewalletRepository.save(any(Ewallet.class))).thenReturn(wallet);
        when(statementRepository.findAll()).thenReturn(List.of());

        ewalletService.updateWallet(101, 200.0, "Test Credit", "Credit");

        assertEquals(1200.0, wallet.getCurrentBalance());
        verify(ewalletRepository).save(wallet);
    }


    @Test
    void testUpdateWallet_Debit_Success() {
        when(ewalletRepository.findByUserId(101)).thenReturn(wallet);
        when(ewalletRepository.save(any(Ewallet.class))).thenReturn(wallet);
        when(statementRepository.findAll()).thenReturn(List.of());

        ewalletService.updateWallet(101, 500.0, "Test Debit", "Debit");

        assertEquals(500.0, wallet.getCurrentBalance());
        verify(ewalletRepository).save(wallet);
    }


    @Test
    void testGetBalance_Success() throws Exception {
        when(ewalletRepository.findByUserId(101)).thenReturn(wallet);
        Double balance = ewalletService.getBalance(101);
        assertEquals(1000.0, balance);
    }

    @Test
    void testGetBalance_WalletNotFound() {
        when(ewalletRepository.findByUserId(999)).thenReturn(null);
        Exception exception = assertThrows(Exception.class, () -> ewalletService.getBalance(999));
        assertTrue(exception.getMessage().contains("Wallet not found"));
    }

    @Test
    void testGetStatements() {
        Statement s1 = new Statement();
        when(statementRepository.findAll()).thenReturn(List.of(s1));
        List<Statement> result = ewalletService.getStatemants();
        assertEquals(1, result.size());
    }

    @Test
    void testGetStatementsByWalletId() {
        Statement s1 = new Statement();
        when(statementRepository.findByEwallet_WalletId(1)).thenReturn(List.of(s1));
        List<Statement> result = ewalletService.getStatemantsById(1);
        assertEquals(1, result.size());
    }

    @Test
    void testDeleteById() {
        doNothing().when(ewalletRepository).deleteById(1);
        doNothing().when(statementRepository).deleteById(1);
        ewalletService.deleteById(1);
        verify(ewalletRepository).deleteById(1);
        verify(statementRepository).deleteById(1);
    }

    @Test
    void testGetById() {
        when(ewalletRepository.findById(1)).thenReturn(Optional.of(wallet));
        Ewallet result = ewalletService.getById(1);
        assertEquals(wallet, result);
    }
}
