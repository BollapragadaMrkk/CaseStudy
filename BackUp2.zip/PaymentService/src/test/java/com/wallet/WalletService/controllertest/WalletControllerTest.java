package com.wallet.WalletService.controllertest;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.payment.controller.EwalletController;
import com.payment.entity.Ewallet;
import com.payment.entity.Statement;
import com.payment.service.EwalletServiceImpl;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(EwalletController.class)
class EwalletControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EwalletServiceImpl ewalletService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void testGetAllWallets() throws Exception {
        Ewallet wallet = new Ewallet();
        Mockito.when(ewalletService.getWallets()).thenReturn(List.of(wallet));

        mockMvc.perform(get("/wallet/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0]").exists());
    }

    @Test
    void testAddWallet() throws Exception {
        Ewallet wallet = new Ewallet();
        wallet.setWalletId(1);
        wallet.setUserId(101);
        Mockito.when(ewalletService.addWallet(any(Ewallet.class))).thenReturn(wallet);

        mockMvc.perform(post("/wallet/add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(wallet)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.walletId").value(1));
    }

    @Test
    void testAddMoneySuccess() throws Exception {
        Ewallet wallet = new Ewallet();
        Mockito.when(ewalletService.getById(1)).thenReturn(wallet);

        mockMvc.perform(put("/wallet/addMoney/1")
                        .param("amount", "200.0"))
                .andExpect(status().isOk());

        Mockito.verify(ewalletService).addMoney(1, 200.0);
    }

    @Test
    void testAddMoneyNotFound() throws Exception {
        Mockito.when(ewalletService.getById(1)).thenReturn(null);

        mockMvc.perform(put("/wallet/addMoney/1")
                        .param("amount", "100.0"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testUpdateWalletByUserId() throws Exception {
        mockMvc.perform(put("/wallet/update/101")
                        .param("amount", "100.0")
                        .param("transactionType", "Credit")
                        .param("transactionRemarks", "Test credit"))
                .andExpect(status().isOk());

        Mockito.verify(ewalletService).updateWallet(eq(101), eq(100.0), eq("Test credit"), eq("Credit"));
    }
//    @Test
//    void testUpdateWalletByUserId() throws Exception {
//        Integer orderId = 12345; // Example orderId
//
//        mockMvc.perform(put("/wallet/update/101")
//                        .param("amount", "100.0")
//                        .param("transactionType", "Credit")
//                        .param("transactionRemarks", "Test credit")
//                        .param("orderId", String.valueOf(orderId))) // Add orderId as a request parameter
//                .andExpect(status().isOk());
//
//        Mockito.verify(ewalletService).updateWallet(eq(101), eq(100.0), eq("Test credit"), eq("Credit"), eq(orderId)); // Verify that orderId is passed correctly
//    }


    @Test
    void testGetWalletById() throws Exception {
        Ewallet wallet = new Ewallet();
        wallet.setWalletId(1);
        Mockito.when(ewalletService.getById(1)).thenReturn(wallet);

        mockMvc.perform(get("/wallet/id/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.walletId").value(1));
    }

    @Test
    void testGetWalletById_NotFound() throws Exception {
        Mockito.when(ewalletService.getById(1)).thenReturn(null);

        mockMvc.perform(get("/wallet/id/1"))
                .andExpect(status().isNotFound());
    }

    @Test
    void testGetCurrentBalance() throws Exception {
        Mockito.when(ewalletService.getBalance(101)).thenReturn(500.0);

        mockMvc.perform(get("/wallet/balance/101"))
                .andExpect(status().isOk())
                .andExpect(content().string("500.0"));
    }

    @Test
    void testGetAllStatements() throws Exception {
        Statement stmt = new Statement();
        Mockito.when(ewalletService.getStatemants()).thenReturn(List.of(stmt));

        mockMvc.perform(get("/wallet/statements/all"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0]").exists());
    }

    @Test
    void testGetStatementsByWalletId() throws Exception {
        Statement stmt = new Statement();
        Mockito.when(ewalletService.getStatemantsById(1)).thenReturn(List.of(stmt));

        mockMvc.perform(get("/wallet/statements/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0]").exists());
    }

    @Test
    void testDeleteWallet() throws Exception {
        mockMvc.perform(delete("/wallet/delete/1"))
                .andExpect(status().isOk());

        Mockito.verify(ewalletService).deleteById(1);
    }
}
