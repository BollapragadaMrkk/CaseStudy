package com.theatre.service;

import com.theatre.entity.Theatre;
import com.theatre.repository.TheatreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TheatreService {

    @Autowired
    private TheatreRepository theatreRepository;

    
    public List<Theatre> getAllTheatres() {
        return theatreRepository.findAll();
    }

    
    public Theatre getTheatreById(Long id) {
        Optional<Theatre> theatre = theatreRepository.findById(id);
        return theatre.orElse(null);
    }

    
    public Theatre createTheatre(Theatre theatre) {
        return theatreRepository.save(theatre);
    }

   
    public Theatre updateTheatre(Long id, Theatre theatre) {
        if (theatreRepository.existsById(id)) {
            theatre.setId(id);
            return theatreRepository.save(theatre);
        }
        return null;
    }

    
    public boolean deleteTheatre(Long id) {
        if (theatreRepository.existsById(id)) {
            theatreRepository.deleteById(id);
            return true;
        }
        return false;
    }
}

