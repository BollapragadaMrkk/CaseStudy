package com.rating.controller;

import com.rating.entity.Rating;
import com.rating.dto.RatingDetailsDTO;
import com.rating.service.RatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/ratings")
public class RatingController {
    @Autowired
    private RatingService ratingService;

    @PostMapping
    public Rating addRating(@RequestBody Rating rating) {
        return ratingService.addRating(rating);
    }

    @GetMapping("/movie/{movieId}")
    public List<RatingDetailsDTO> getRatingsByMovie(@PathVariable Long movieId) {
        return ratingService.getRatingsByMovieId(movieId);
    }

    @GetMapping("/user/{userId}")
    public List<RatingDetailsDTO> getRatingsByUser(@PathVariable Long userId) {
        return ratingService.getRatingsByUserId(userId);
    }
}
