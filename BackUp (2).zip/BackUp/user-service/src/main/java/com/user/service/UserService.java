package com.user.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.user.entity.UserEntity;
import com.user.repository.UserRepository;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public UserEntity getUserByEmail(String userEmail) {
        return userRepository.findByUserEmail(userEmail);
    }
    public UserEntity getUserByPhone(String userPhone) {
        return userRepository.findByUserPhone(userPhone);
    }
    public UserEntity getUserById(int userId) {
        return userRepository.findById(userId).orElse(null);
    }
    public UserEntity createUser(UserEntity user) {
        return userRepository.save(user);
    }
    public UserEntity updateUser(int userId, UserEntity updatedUser) {
        if (userRepository.existsById(userId)) {
            updatedUser.setUserId(userId);
            return userRepository.save(updatedUser);
        }
        return null;
    }
    public boolean deleteUser(int userId) {
        if (userRepository.existsById(userId)) {
            userRepository.deleteByUserId(userId);
            return true;
        }
        return false;
    }
    public List<UserEntity> getAllUsers() {
        return userRepository.findAll();
    }
}
