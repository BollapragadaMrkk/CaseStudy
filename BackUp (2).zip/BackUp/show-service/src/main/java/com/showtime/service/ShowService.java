package com.showtime.service;

import com.showtime.model.Show;
import com.showtime.repository.ShowRepository;
import com.showtime.client.MovieClient;
import com.showtime.client.TheatreClient;
import com.showtime.dto.MovieDTO;
import com.showtime.dto.TheatreDTO;
import com.showtime.dto.ShowDetailsDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ShowService {

    @Autowired
    private ShowRepository showRepository;

    @Autowired
    private MovieClient movieClient;

    @Autowired
    private TheatreClient theatreClient;

    public List<Show> getAllShows() {
        return showRepository.findAll();
    }

    public Show getShowById(Long id) {
        return showRepository.findById(id).orElse(null);
    }

    public Show createShow(Show show) {
        return showRepository.save(show);
    }

    public Show updateShow(Long id, Show show) {
        if (showRepository.existsById(id)) {
            show.setId(id);
            return showRepository.save(show);
        }
        return null;
    }

    public boolean deleteShow(Long id) {
        if (showRepository.existsById(id)) {
            showRepository.deleteById(id);
            return true;
        }
        return false;
    }

    public List<Show> getShowsByMovieId(Long movieId) {
        return showRepository.findByMovieId(movieId);
    }

    public List<Show> getShowsByTheatreId(Long theatreId) {
        return showRepository.findByTheatreId(theatreId);
    }

    public ShowDetailsDTO getShowDetails(Long showId) {
        Show show = getShowById(showId);
        if (show == null) return null;
        MovieDTO movie = movieClient.getMovieById(show.getMovieId());
        TheatreDTO theatre = theatreClient.getTheatreById(show.getTheatreId());
        ShowDetailsDTO dto = new ShowDetailsDTO();
        dto.setId(show.getId());
        dto.setMovie(movie);
        dto.setTheatre(theatre);
        dto.setShowTime(show.getShowTime());
        dto.setAvailableSeats(show.getAvailableSeats());
        dto.setTotalSeats(show.getTotalSeats());
        return dto;
    }

    public List<ShowDetailsDTO> getAllShowDetails() {
        return getAllShows().stream()
            .map(show -> getShowDetails(show.getId()))
            .collect(Collectors.toList());
    }
}
