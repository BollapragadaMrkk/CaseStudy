package com.rating.dto;

import java.time.LocalDate;
import java.util.List;

public class MovieDTO {
    private Long id;
    private String moviename;
    private String description;
    private String posterofmovie;
    private LocalDate releaseDate;
    private List<String> genre;
    private int duration;

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getMoviename() { return moviename; }
    public void setMoviename(String moviename) { this.moviename = moviename; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getPosterofmovie() { return posterofmovie; }
    public void setPosterofmovie(String posterofmovie) { this.posterofmovie = posterofmovie; }
    public LocalDate getReleaseDate() { return releaseDate; }
    public void setReleaseDate(LocalDate releaseDate) { this.releaseDate = releaseDate; }
    public List<String> getGenre() { return genre; }
    public void setGenre(List<String> genre) { this.genre = genre; }
    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }
}

