package com.movie.controller;

import com.movie.dto.MovieDTO;
import com.movie.model.Movie;
import com.movie.repository.MovieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/movies")
public class MovieController {

    @Autowired
    private MovieRepository movieRepository;

    @GetMapping("/all")
    public List<Movie> getAllMovies() {
        return movieRepository.findAll();
    }

    @PostMapping("/add")
    public Movie addMovie(@RequestBody MovieDTO movieDTO) {
        Movie movie = new Movie();
        movie.setMoviename(movieDTO.getMoviename());
        movie.setDescription(movieDTO.getDescription());
        movie.setPosterofmovie(movieDTO.getPosterofmovie());
        movie.setReleaseDate(movieDTO.getReleaseDate());
        movie.setGenre(movieDTO.getGenre());
        movie.setDuration(movieDTO.getDuration());
        return movieRepository.save(movie);
    }

    @GetMapping("/{id}")
    public Movie getMovieById(@PathVariable Long id) {
        return movieRepository.findById(id).orElse(null);
    }

    @GetMapping("/moviename/{moviename}")
    public List<Movie> getMoviesByName(@PathVariable String moviename) {
        return movieRepository.findByMoviename(moviename);
    }

    @PutMapping("/{id}")
    public Movie updateMovie(@PathVariable Long id, @RequestBody MovieDTO movieDTO) {
        if (movieRepository.existsById(id)) {
            Movie movie = new Movie();
            movie.setId(id);
            movie.setMoviename(movieDTO.getMoviename());
            movie.setDescription(movieDTO.getDescription());
            movie.setPosterofmovie(movieDTO.getPosterofmovie());
            movie.setReleaseDate(movieDTO.getReleaseDate());
            movie.setGenre(movieDTO.getGenre());
            movie.setDuration(movieDTO.getDuration());
            return movieRepository.save(movie);
        }
        return null;
    }

    @DeleteMapping("/{id}")
    public void deleteMovie(@PathVariable Long id) {
        movieRepository.deleteById(id);
    }

    @DeleteMapping("/moviename/{moviename}")
    public void deleteMovieByName(@PathVariable String moviename) {
        List<Movie> movies = movieRepository.findByMoviename(moviename);
        for (Movie movie : movies) {
            movieRepository.delete(movie);
        }
    }
}
