package com.gateway.APIgateway.controller;

import com.gateway.APIgateway.dto.UserDetailsDTO;
import com.gateway.APIgateway.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private WebClient.Builder webClientBuilder;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public Mono<Map<String, String>> login(@RequestBody Map<String, String> loginRequest) {
        String username = loginRequest.get("username");
        String password = loginRequest.get("password");

        return webClientBuilder.build()
            .get()
            .uri("http://user-service/user/email/{userEmail}", username)
            .retrieve()
            .bodyToMono(UserDetailsDTO.class)
            .filter(user -> user != null && passwordEncoder.matches(password, user.getPassword()))
            .switchIfEmpty(Mono.error(new RuntimeException("Invalid username or password")))
            .map(user -> {
                String token = jwtUtil.generateToken(username);
                Map<String, String> response = new HashMap<>();
                response.put("token", token);
                return response;
            });
    }
}
