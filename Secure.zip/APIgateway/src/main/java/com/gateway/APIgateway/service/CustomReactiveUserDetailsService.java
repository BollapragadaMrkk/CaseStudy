package com.gateway.APIgateway.service;

import com.gateway.APIgateway.client.UserClient;
import com.gateway.APIgateway.dto.UserDetailsDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class CustomReactiveUserDetailsService implements ReactiveUserDetailsService {

    @Autowired
    private UserClient userClient;

    @Override
    public Mono<UserDetails> findByUsername(String username) {
        try {
            UserDetailsDTO user = userClient.getUserByEmail(username);
            if (user == null) {
                return Mono.empty();
            }
            return Mono.just(
                User.withUsername(user.getUserEmail())
                    .password(user.getPassword())
                    .roles(user.getRole() != null ? user.getRole().toUpperCase() : "USER")
                    .build()
            );
        } catch (Exception e) {
            return Mono.empty();
        }
    }
}
