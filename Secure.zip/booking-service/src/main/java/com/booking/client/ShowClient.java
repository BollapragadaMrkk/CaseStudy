package com.booking.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.booking.dto.ShowDetailsDTO;

@FeignClient(name = "show-service")
public interface ShowClient {
    @GetMapping("/shows/{id}/details")
    ShowDetailsDTO getShowDetailsById(@PathVariable("id") Long id);
}

