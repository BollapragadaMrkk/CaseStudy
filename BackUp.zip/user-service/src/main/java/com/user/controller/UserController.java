package com.user.controller;

import com.user.dto.UserRequestDTO;
import com.user.entity.UserEntity;
import com.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @GetMapping("/{userId}")
    public ResponseEntity<UserEntity> getUserById(@PathVariable int userId) {
        UserEntity user = userService.getUserById(userId);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    @GetMapping("/email/{userEmail}")
    public ResponseEntity<UserEntity> getUserByEmail(@PathVariable String userEmail) {
        UserEntity user = userService.getUserByEmail(userEmail);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    @GetMapping("/phone/{userPhone}")
    public ResponseEntity<UserEntity> getUserByPhone(@PathVariable String userPhone) {
        UserEntity user = userService.getUserByPhone(userPhone);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    @GetMapping("/all")
    public ResponseEntity<List<UserEntity>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @PostMapping("/create")
    public ResponseEntity<UserEntity> createUser(@RequestBody UserRequestDTO newUser) {
        UserEntity user = new UserEntity();
        user.setUserName(newUser.getUserName());
        user.setUserEmail(newUser.getUserEmail());
        user.setUserPhone(newUser.getUserPhone());
        user.setPassword(newUser.getPassword());
        UserEntity createdUser = userService.createUser(user);
        return ResponseEntity.ok(createdUser);
    }

    @PutMapping("/update/{userId}")
    public ResponseEntity<UserEntity> updateUser(@PathVariable int userId, @RequestBody UserRequestDTO updatedUser) {
        UserEntity existingUser = userService.getUserById(userId);
        if (existingUser != null) {
            existingUser.setUserName(updatedUser.getUserName());
            existingUser.setUserEmail(updatedUser.getUserEmail());
            existingUser.setUserPhone(updatedUser.getUserPhone());
            existingUser.setPassword(updatedUser.getPassword());
            UserEntity user = userService.updateUser(userId, existingUser);
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/delete/{userId}")
    public ResponseEntity<Void> deleteUser(@PathVariable int userId) {
        return userService.deleteUser(userId) ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }
}
