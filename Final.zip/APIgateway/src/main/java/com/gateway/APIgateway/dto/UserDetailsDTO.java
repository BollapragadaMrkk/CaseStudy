package com.gateway.APIgateway.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserDetailsDTO {
    @JsonProperty("userEmail")
    private String userEmail;
    
    @JsonProperty("password")
    private String password;
    
    @JsonProperty("role")
    private String role;

    public String getUserEmail() { return userEmail; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
}
