package com.gateway.APIgateway.controller;

import com.gateway.APIgateway.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;
import java.util.Map;
import java.util.HashMap;

@RestController
@RequestMapping("/auth")
@CrossOrigin(origins = "*")
public class AuthController {
    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private ReactiveUserDetailsService userDetailsService;

    @Autowired
    private WebClient.Builder webClientBuilder;

    @PostMapping("/login")
    public Mono<ResponseEntity<?>> login(@RequestBody Map<String, String> credentials) {
        String username = credentials.get("username");
        String password = credentials.get("password");
        
        logger.info("Login attempt for user: {}", username);

        return userDetailsService.findByUsername(username)
            .flatMap(userDetails -> {
                logger.info("User found, comparing passwords");
                if (password.equals(userDetails.getPassword())) {
                    String role = userDetails.getAuthorities().stream()
                        .findFirst()
                        .map(authority -> authority.getAuthority())
                        .orElse("ROLE_USER");
                    
                    logger.info("Password matches, generating token with role: {}", role);
                    
                    String token = jwtUtil.generateToken(username, role);
                    Map<String, String> response = new HashMap<>();
                    response.put("token", token);
                    response.put("role", role);
                    
                    return Mono.just(ResponseEntity.ok(response));
                } else {
                    logger.warn("Password does not match for user: {}", username);
                    return Mono.just(ResponseEntity.badRequest().body("Invalid credentials"));
                }
            })
            .switchIfEmpty(Mono.defer(() -> {
                logger.warn("User not found: {}", username);
                return Mono.just(ResponseEntity.badRequest().body("Invalid credentials"));
            }));
    }

    @PostMapping("/register")
    public Mono<ResponseEntity<?>> register(@RequestBody Map<String, String> userData) {
        logger.info("Registration attempt for user: {}", userData.get("userEmail"));
        
        return webClientBuilder.build()
            .post()
            .uri("http://user-service/user/create")
            .bodyValue(userData)
            .retrieve()
            .toEntity(Map.class)
            .flatMap(response -> {
                if (response.getStatusCode().is2xxSuccessful()) {
                    logger.info("User registered successfully: {}", userData.get("userEmail"));
                    return Mono.just(ResponseEntity.ok(response.getBody()));
                } else {
                    logger.error("Failed to register user: {}", userData.get("userEmail"));
                    return Mono.just(ResponseEntity.badRequest().body("Registration failed"));
                }
            })
            .onErrorResume(e -> {
                logger.error("Error during registration: {}", e.getMessage());
                return Mono.just(ResponseEntity.badRequest().body("Registration failed: " + e.getMessage()));
            });
    }
}
