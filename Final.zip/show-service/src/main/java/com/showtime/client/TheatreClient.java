package com.showtime.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.showtime.dto.TheatreDTO;

@FeignClient(name = "theatre-service")
public interface TheatreClient {
    @GetMapping("/theatres/{id}")
    TheatreDTO getTheatreById(@PathVariable("id") Long id);
}

