package com.movie.model;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDate;
import java.util.List;

@Entity
public class Movie {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Movie name cannot be blank")
    private String moviename;

    @NotBlank(message = "Description cannot be blank")
    private String description;

    @NotBlank(message = "Poster URL cannot be blank")
    private String posterofmovie;

    private LocalDate releaseDate;

    @ElementCollection
    private List<String> genre;
    @Min(value = 90, message = "Duration must be at least 90 minute")
    private int duration;

    // Getters and setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getMoviename() { return moviename; }
    public void setMoviename(String moviename) { this.moviename = moviename; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getPosterofmovie() { return posterofmovie; }
    public void setPosterofmovie(String posterofmovie) { this.posterofmovie = posterofmovie; }

    public LocalDate getReleaseDate() { return releaseDate; }
    public void setReleaseDate(LocalDate releaseDate) { this.releaseDate = releaseDate; }

    public List<String> getGenre() { return genre; }
    public void setGenre(List<String> genre) { this.genre = genre; }

    public int getDuration() { return duration; }
    public void setDuration(int duration) { this.duration = duration; }
}
