package com.user.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "users")
public class UserEntity {
    private static final Logger logger = LoggerFactory.getLogger(UserEntity.class);

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;
    private String userName;
    private String userEmail;
    private String userPhone;
    private String password;
    private String role;
    
    
    public UserEntity() {
		super();
	}
    
    public UserEntity(String userName, String userEmail, String userPhone, String password) {
		this.userName = userName;
		this.userEmail = userEmail;
		this.userPhone = userPhone;
		this.password = password;
		// Set role based on email domain
		setUserEmail(userEmail);
	}

	// Getters and Setters
	public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Long getUserId() {
        return userId;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getUserEmail() {
        return userEmail;
    }
    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
        // Set role based on email domain
        if (userEmail != null && userEmail.endsWith("@moviemagic.com")) {
            this.role = "ROLE_ADMIN";
            logger.info("Setting role to ROLE_ADMIN for email: {}", userEmail);
        } else {
            this.role = "ROLE_USER";
            logger.info("Setting role to ROLE_USER for email: {}", userEmail);
        }
    }
    public String getUserPhone() {
        return userPhone;
    }
    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        if (role != null) {
            // Ensure role has ROLE_ prefix and is uppercase
            this.role = role.startsWith("ROLE_") ? role.toUpperCase() : "ROLE_" + role.toUpperCase();
            logger.info("Role set to: {}", this.role);
        } else {
            this.role = "ROLE_USER";
            logger.info("No role provided, defaulting to ROLE_USER");
        }
    }

    @Override
    public String toString() {
        return "UserEntity [userId=" + userId + ", userName=" + userName + ", userEmail=" + userEmail + ", userPhone=" + userPhone + ", role=" + role + "]";
    }

    public UserEntity(Long userId, String userName, String userEmail, String userPhone) {
        this.userId = userId;
        this.userName = userName;
        setUserEmail(userEmail);
        this.userPhone = userPhone;
    }

    @PrePersist
    @PreUpdate
    public void validateRole() {
        if (this.role == null) {
            this.role = "ROLE_USER";
            logger.info("Role was null, defaulting to ROLE_USER");
        } else if (!this.role.startsWith("ROLE_")) {
            this.role = "ROLE_" + this.role.toUpperCase();
            logger.info("Role prefix added: {}", this.role);
        }
    }
}
