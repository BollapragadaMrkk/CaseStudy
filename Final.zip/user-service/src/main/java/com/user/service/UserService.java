package com.user.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.user.entity.UserEntity;
import com.user.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class UserService {
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Autowired
    private UserRepository userRepository;

    public UserEntity getUserByEmail(String email) {
        logger.info("Finding user by email: {}", email);
        return userRepository.findByUserEmail(email);
    }
    
    public UserEntity getUserByPhone(String phone) {
        logger.info("Finding user by phone: {}", phone);
        return userRepository.findByUserPhone(phone);
    }
    
    public UserEntity getUserById(Long userId) {
        return userRepository.findByUserId(userId).orElse(null);
    }
    
    public UserEntity createUser(UserEntity user) {
        logger.info("Creating new user with email: {}", user.getUserEmail());
        // Role will be set by UserEntity's setUserEmail method
        return userRepository.save(user);
    }
    
    public UserEntity updateUser(Long userId, UserEntity user) {
        logger.info("Updating user with ID: {}", userId);
        UserEntity existingUser = userRepository.findByUserId(userId).orElse(null);
        if (existingUser != null) {
            existingUser.setUserName(user.getUserName());
            existingUser.setUserEmail(user.getUserEmail());
            existingUser.setUserPhone(user.getUserPhone());
            if (user.getPassword() != null && !user.getPassword().isEmpty()) {
                existingUser.setPassword(user.getPassword());
            }
            // Role will be updated by UserEntity's setUserEmail method
            return userRepository.save(existingUser);
        }
        return null;
    }
    
    public void deleteUser(Long userId) {
        logger.info("Deleting user with ID: {}", userId);
        userRepository.deleteByUserId(userId);
    }
    
    public List<UserEntity> getAllUsers() {
        logger.info("Fetching all users");
        return userRepository.findAll();
    }
}
