package com.user.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import com.user.entity.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, Integer> {
    UserEntity findByUserEmail(String userEmail);
    UserEntity findByUserPhone(String userPhone);
    void deleteByUserId(Long userId);
	Optional<UserEntity> findByUserId(Long userId);

}

