package com.booking.service;

import com.booking.entity.Booking;
import com.booking.dto.BookingRequestDTO;
import com.booking.dto.ShowDetailsDTO;
import com.booking.repository.BookingRepository;
import com.booking.client.ShowClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private ShowClient showClient;

    public Booking createBooking(BookingRequestDTO request) {
        Booking booking = new Booking();
        booking.setUserId(request.getUserId());
        booking.setShowId(request.getShowId());
        booking.setSeatNumbers(request.getSeatNumbers());
        booking.setBookingTime(LocalDateTime.now());
        booking.setStatus("CONFIRMED");
        return bookingRepository.save(booking);
    }

    public Booking cancelBooking(Long bookingId) {
        Booking booking = bookingRepository.findById(bookingId)
            .orElseThrow(() -> new RuntimeException("Booking not found"));
        booking.setStatus("CANCELLED");
        return bookingRepository.save(booking);
    }

    public void deleteBooking(Long bookingId) {
        if (!bookingRepository.existsById(bookingId)) {
            throw new RuntimeException("Booking not found");
        }
        bookingRepository.deleteById(bookingId);
    }

    public List<Booking> getBookingsByUserId(Long userId) {
        return bookingRepository.findByUserId(userId);
    }

    public List<Booking> getBookingsByShowId(Long showId) {
        return bookingRepository.findByShowId(showId);
    }

    public ShowDetailsDTO getShowDetailsForBooking(Long showId) {
        return showClient.getShowDetailsById(showId);
    }
}
