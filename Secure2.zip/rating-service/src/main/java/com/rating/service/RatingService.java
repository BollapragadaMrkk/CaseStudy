package com.rating.service;

import com.rating.entity.Rating;
import com.rating.repository.RatingRepository;
import com.rating.client.UserClient;
import com.rating.client.MovieClient;
import com.rating.dto.RatingDetailsDTO;
import com.rating.dto.UserDTO;
import com.rating.dto.MovieDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RatingService {
    @Autowired
    private RatingRepository ratingRepository;
    @Autowired
    private UserClient userClient;
    @Autowired
    private MovieClient movieClient;

    public Rating addRating(Rating rating) {
        if (ratingRepository.findByUserIdAndMovieId(rating.getUserId(), rating.getMovieId()) != null) {
            throw new RuntimeException("User has already rated this movie.");
        }
        return ratingRepository.save(rating);
    }

    public List<RatingDetailsDTO> getRatingsByMovieId(Long movieId) {
        return ratingRepository.findByMovieId(movieId).stream()
            .map(this::toDetailsDTO)
            .collect(Collectors.toList());
    }

    public List<RatingDetailsDTO> getRatingsByUserId(Long userId) {
        return ratingRepository.findByUserId(userId).stream()
            .map(this::toDetailsDTO)
            .collect(Collectors.toList());
    }

    private RatingDetailsDTO toDetailsDTO(Rating rating) {
        UserDTO user = userClient.getUserById(rating.getUserId());
        MovieDTO movie = movieClient.getMovieById(rating.getMovieId());
        RatingDetailsDTO dto = new RatingDetailsDTO();
        dto.setId(rating.getId());
        dto.setUser(user);
        dto.setMovie(movie);
        dto.setRating(rating.getRating());
        dto.setComment(rating.getComment());
        return dto;
    }
}

