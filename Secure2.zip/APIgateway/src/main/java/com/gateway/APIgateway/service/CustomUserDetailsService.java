package com.gateway.APIgateway.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;
import java.util.Collections;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

@Service
@Primary
public class CustomUserDetailsService implements ReactiveUserDetailsService {
    private static final Logger logger = LoggerFactory.getLogger(CustomUserDetailsService.class);

    @Autowired
    private WebClient.Builder webClientBuilder;

    @Override
    public Mono<UserDetails> findByUsername(String username) {
        if (username == null || username.trim().isEmpty()) {
            logger.error("Username is null or empty");
            return Mono.error(new ResponseStatusException(HttpStatus.BAD_REQUEST, "Username cannot be empty"));
        }

        logger.info("Finding user by username: {}", username);
        
        return webClientBuilder.build()
            .get()
            .uri("http://user-service/user/email/{email}", username)
            .retrieve()
            .bodyToMono(UserDetailsDTO.class)
            .map(user -> {
                if (user == null) {
                    logger.error("User not found for username: {}", username);
                    throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found");
                }

                if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
                    logger.error("User has no password set: {}", username);
                    throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "User has no password set");
                }

                logger.info("User found: {} with role: {}", user.getUserEmail(), user.getRole());
                
                String role = user.getRole();
                if (role == null) {
                    role = "ROLE_USER";
                    logger.info("No role found, defaulting to ROLE_USER");
                } else if (!role.startsWith("ROLE_")) {
                    role = "ROLE_" + role.toUpperCase();
                    logger.info("Role prefix added: {}", role);
                }

                logger.info("Creating UserDetails with role: {}", role);
                UserDetails userDetails = User.builder()
                    .username(user.getUserEmail())
                    .password(user.getPassword())
                    .authorities(Collections.singletonList(new SimpleGrantedAuthority(role)))
                    .build();
                
                logger.info("UserDetails created successfully");
                return userDetails;
            })
            .doOnError(e -> {
                if (e instanceof ResponseStatusException) {
                    logger.error("Error finding user: {}", e.getMessage());
                } else {
                    logger.error("Unexpected error finding user: {}", e.getMessage());
                }
            })
            .onErrorResume(e -> {
                if (e instanceof ResponseStatusException) {
                    return Mono.error(e);
                }
                logger.error("User not found or error occurred: {}", e.getMessage());
                return Mono.error(new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error finding user"));
            });
    }
}

class UserDetailsDTO {
    private String userEmail;
    private String password;
    private String role;

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public String toString() {
        return "UserDetailsDTO{" +
            "userEmail='" + userEmail + '\'' +
            ", role='" + role + '\'' +
            '}';
    }
} 