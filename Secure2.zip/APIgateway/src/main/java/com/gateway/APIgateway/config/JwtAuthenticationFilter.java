package com.gateway.APIgateway.config;

import com.gateway.APIgateway.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.userdetails.ReactiveUserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class JwtAuthenticationFilter implements WebFilter {
    private static final Logger logger = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private ReactiveUserDetailsService userDetailsService;

    private final List<String> publicPaths = List.of(
        "/auth/login",
        "/auth/register",
        "/user/create",
        "/user/email/",
        "/user/phone/",
        "/movies/list",
        "/movies/moviename/"
    );

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        String path = exchange.getRequest().getPath().value();
        logger.info("Processing request for path: {}", path);

        // Check if the path is public
        if (publicPaths.stream().anyMatch(path::startsWith)) {
            logger.info("Public path accessed: {}", path);
            return chain.filter(exchange);
        }

        String authHeader = exchange.getRequest().getHeaders().getFirst("Authorization");
        logger.info("Auth header present: {}", authHeader != null);

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            logger.warn("No valid Authorization header found");
            return chain.filter(exchange);
        }

        String token = authHeader.substring(7);
        logger.info("Token extracted: {}", token);

        return jwtUtil.validateToken(token)
            .flatMap(valid -> {
                if (!valid) {
                    logger.warn("Invalid token");
                    return chain.filter(exchange);
                }

                String username = jwtUtil.getUsernameFromToken(token);
                List<String> roles = jwtUtil.getRolesFromToken(token);
                logger.info("Token validated for user: {} with roles: {}", username, roles);

                return userDetailsService.findByUsername(username)
                    .flatMap(userDetails -> {
                        List<SimpleGrantedAuthority> authorities = roles.stream()
                            .map(SimpleGrantedAuthority::new)
                            .collect(Collectors.toList());

                        logger.info("User authorities: {}", authorities);

                        UsernamePasswordAuthenticationToken authentication = 
                            new UsernamePasswordAuthenticationToken(
                                userDetails,
                                null,
                                authorities
                            );

                        return chain.filter(exchange)
                            .contextWrite(ReactiveSecurityContextHolder.withAuthentication(authentication));
                    });
            })
            .switchIfEmpty(chain.filter(exchange));
    }
}
