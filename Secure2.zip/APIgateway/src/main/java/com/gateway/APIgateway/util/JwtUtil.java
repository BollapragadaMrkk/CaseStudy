package com.gateway.APIgateway.util;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import reactor.core.publisher.Mono;
import java.security.Key;
import java.util.Date;
import java.util.List;
import java.util.Arrays;
import java.util.stream.Collectors;

@Component
public class JwtUtil {
    private static final Logger logger = LoggerFactory.getLogger(JwtUtil.class);
    private static final Key key = Keys.secretKeyFor(SignatureAlgorithm.HS256);
    private static final long EXPIRATION_TIME = 864_000_000; // 10 days

    public String generateToken(String username, String role) {
        logger.info("Generating token for user: {} with role: {}", username, role);
        return Jwts.builder()
                .setSubject(username)
                .claim("roles", role)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))
                .signWith(key)
                .compact();
    }

    public Mono<Boolean> validateToken(String token) {
        logger.info("Validating token");
        try {
            Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token);
            logger.info("Token is valid");
            return Mono.just(true);
        } catch (Exception e) {
            logger.error("Token validation failed: {}", e.getMessage());
            return Mono.just(false);
        }
    }

    public String getUsernameFromToken(String token) {
        logger.info("Extracting username from token");
        try {
            Claims claims = Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
            String username = claims.getSubject();
            logger.info("Username extracted: {}", username);
            return username;
        } catch (Exception e) {
            logger.error("Failed to extract username from token: {}", e.getMessage());
            return null;
        }
    }

    public List<String> getRolesFromToken(String token) {
        logger.info("Extracting roles from token");
        try {
            Claims claims = Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
            
            String roles = claims.get("roles", String.class);
            List<String> roleList = Arrays.asList(roles.split(","));
            
            // Ensure roles have ROLE_ prefix
            roleList = roleList.stream()
                .map(role -> role.startsWith("ROLE_") ? role : "ROLE_" + role)
                .collect(Collectors.toList());
            
            logger.info("Roles extracted: {}", roleList);
            return roleList;
        } catch (Exception e) {
            logger.error("Failed to extract roles from token: {}", e.getMessage());
            return List.of("ROLE_USER"); // Default to USER role if extraction fails
        }
    }
}
