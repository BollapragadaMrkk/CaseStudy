package com.gateway.APIgateway.client;

import com.gateway.APIgateway.dto.UserDetailsDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "user-service")
public interface UserClient {
    @GetMapping("/user/email/{userEmail}")
    UserDetailsDTO getUserByEmail(@PathVariable("userEmail") String userEmail);
}
