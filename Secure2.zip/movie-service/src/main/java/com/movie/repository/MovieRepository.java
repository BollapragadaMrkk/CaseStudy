package com.movie.repository;

import com.movie.model.Movie;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MovieRepository extends JpaRepository<Movie, Long> {
		// Additional query methods can be defined here if needed
	// For example, to find movies by genre:
	 List<Movie> findByMoviename(String moviename);
}

