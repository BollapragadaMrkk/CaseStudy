package com.user.controller;

import com.user.entity.UserEntity;
import com.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "*")
public class UserController {
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    @PostMapping("/create")
    public ResponseEntity<UserEntity> createUser(@RequestBody UserEntity user) {
        logger.info("Creating new user with email: {}", user.getUserEmail());
        UserEntity createdUser = userService.createUser(user);
        logger.info("User created with role: {}", createdUser.getRole());
        // Don't send password in response
        createdUser.setPassword(null);
        return ResponseEntity.ok(createdUser);
    }

    @GetMapping("/email/{email}")
    public ResponseEntity<UserEntity> getUserByEmail(@PathVariable String email) {
        logger.info("Fetching user by email: {}", email);
        UserEntity user = userService.getUserByEmail(email);
        if (user != null) {
            logger.info("User found with role: {}", user.getRole());
            // Don't send password in response
            user.setPassword(null);
        }
        return ResponseEntity.ok(user);
    }

    @GetMapping("/phone/{phone}")
    public ResponseEntity<UserEntity> getUserByPhone(@PathVariable String phone) {
        logger.info("Fetching user by phone: {}", phone);
        UserEntity user = userService.getUserByPhone(phone);
        if (user != null) {
            logger.info("User found with role: {}", user.getRole());
            // Don't send password in response
            user.setPassword(null);
        }
        return ResponseEntity.ok(user);
    }

    @GetMapping("/all")
    public ResponseEntity<List<UserEntity>> getAllUsers() {
        logger.info("Fetching all users");
        List<UserEntity> users = userService.getAllUsers();
        // Don't send passwords in response
        users.forEach(user -> user.setPassword(null));
        return ResponseEntity.ok(users);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<UserEntity> updateUser(@PathVariable Long id, @RequestBody UserEntity user) {
        logger.info("Updating user with ID: {}", id);
        UserEntity updatedUser = userService.updateUser(id, user);
        if (updatedUser != null) {
            logger.info("User updated with role: {}", updatedUser.getRole());
            // Don't send password in response
            updatedUser.setPassword(null);
        }
        return ResponseEntity.ok(updatedUser);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        logger.info("Deleting user with ID: {}", id);
        userService.deleteUser(id);
        return ResponseEntity.ok().build();
    }
}
