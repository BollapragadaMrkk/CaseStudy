import React, { useState } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Button,
  Box,
  Chip,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Rating,
  SelectChangeEvent,
} from '@mui/material';
import { useAppDispatch } from '../store/hooks';
import { addMovie } from '../store/slices/movieSlice';
import { Movie } from '../types/movie';

interface AddMovieFormProps {
  open: boolean;
  onClose: () => void;
}

const genres = [
  'Action',
  'Adventure',
  'Comedy',
  'Crime',
  'Drama',
  'Fantasy',
  'Horror',
  'Mystery',
  'Romance',
  'Sci-Fi',
  'Thriller',
];

const AddMovieForm: React.FC<AddMovieFormProps> = ({ open, onClose }) => {
  const dispatch = useAppDispatch();
  const [formData, setFormData] = useState<Omit<Movie, 'id'>>({
    title: '',
    description: '',
    releaseDate: '',
    duration: 0,
    genre: [],
    rating: 0,
    posterUrl: '',
    price: 0,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | { name?: string; value: unknown }>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name as string]: value,
    }));
  };

  const handleGenreChange = (event: SelectChangeEvent<string[]>) => {
    setFormData(prev => ({
      ...prev,
      genre: event.target.value as string[],
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await dispatch(addMovie(formData)).unwrap();
      onClose();
      setFormData({
        title: '',
        description: '',
        releaseDate: '',
        duration: 0,
        genre: [],
        rating: 0,
        posterUrl: '',
        price: 0,
      });
    } catch (error) {
      console.error('Failed to add movie:', error);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Add New Movie</DialogTitle>
      <form onSubmit={handleSubmit}>
        <DialogContent>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            <TextField
              name="title"
              label="Title"
              value={formData.title}
              onChange={handleChange}
              required
              fullWidth
            />
            <TextField
              name="description"
              label="Description"
              value={formData.description}
              onChange={handleChange}
              required
              fullWidth
              multiline
              rows={4}
            />
            <TextField
              name="releaseDate"
              label="Release Date"
              type="date"
              value={formData.releaseDate}
              onChange={handleChange}
              required
              fullWidth
              InputLabelProps={{ shrink: true }}
            />
            <TextField
              name="duration"
              label="Duration (minutes)"
              type="number"
              value={formData.duration}
              onChange={handleChange}
              required
              fullWidth
            />
            <FormControl fullWidth>
              <InputLabel>Genres</InputLabel>
              <Select
                multiple
                value={formData.genre}
                onChange={handleGenreChange}
                renderValue={(selected) => (
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {(selected as string[]).map((value) => (
                      <Chip key={value} label={value} />
                    ))}
                  </Box>
                )}
              >
                {genres.map((genre) => (
                  <MenuItem key={genre} value={genre}>
                    {genre}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            <Box>
              <InputLabel>Rating</InputLabel>
              <Rating
                name="rating"
                value={formData.rating}
                onChange={(_, value) => setFormData(prev => ({ ...prev, rating: value || 0 }))}
                precision={0.5}
              />
            </Box>
            <TextField
              name="posterUrl"
              label="Poster URL"
              value={formData.posterUrl}
              onChange={handleChange}
              required
              fullWidth
            />
            <TextField
              name="price"
              label="Price"
              type="number"
              value={formData.price}
              onChange={handleChange}
              required
              fullWidth
              InputProps={{
                startAdornment: <span>$</span>,
              }}
            />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={onClose}>Cancel</Button>
          <Button type="submit" variant="contained" color="primary">
            Add Movie
          </Button>
        </DialogActions>
      </form>
    </Dialog>
  );
};

export default AddMovieForm; 