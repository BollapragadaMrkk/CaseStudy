import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import {
  Container,
  Typography,
  Box,
  Paper,
  Divider,
  Chip,
  Button,
  TextField,
  Rating,
  Avatar,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  IconButton,
} from '@mui/material';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import StarIcon from '@mui/icons-material/Star';
import LanguageIcon from '@mui/icons-material/Language';
import { movies } from '../data/movies';
import { Comment } from '../types/movie';
import { RootState } from '../store';

const MovieDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [newComment, setNewComment] = useState('');
  const [newRating, setNewRating] = useState<number | null>(null);
  
  const { user, isAuthenticated } = useSelector((state: RootState) => state.auth);
  const movie = movies.find(m => m.id === Number(id));

  if (!movie) {
    return (
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Typography variant="h4">Movie not found</Typography>
        <Button onClick={() => navigate('/movies')} sx={{ mt: 2 }}>
          Back to Movies
        </Button>
      </Container>
    );
  }

  const handleAddComment = () => {
    if (newComment && newRating && user) {
      const comment: Comment = {
        id: movie.comments.length + 1,
        userId: user.id,
        userName: user.username,
        text: newComment,
        rating: newRating,
        date: new Date().toISOString().split('T')[0]
      };
      movie.comments.unshift(comment);
      setNewComment('');
      setNewRating(null);
    }
  };

  return (
    <Container maxWidth="lg" sx={{ py: 8 }}>
      <Box sx={{ 
        display: 'grid', 
        gridTemplateColumns: {
          xs: '1fr',
          md: '1fr 1fr'
        },
        gap: 4
      }}>
        <Box>
          <img
            src={movie.posterUrl}
            alt={movie.title}
            style={{
              width: '100%',
              height: 'auto',
              borderRadius: '8px',
              boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
            }}
          />
        </Box>
        <Box>
          <Typography variant="h3" component="h1" gutterBottom>
            {movie.title}
          </Typography>
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <StarIcon sx={{ color: 'gold', mr: 1 }} />
            <Typography variant="h6">{movie.rating}/10</Typography>
          </Box>
          <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
            <Chip
              icon={<AccessTimeIcon />}
              label={`${Math.floor(movie.duration / 60)}h ${movie.duration % 60}min`}
              variant="outlined"
            />
            <Chip
              icon={<LanguageIcon />}
              label="English"
              variant="outlined"
            />
          </Box>
          <Typography variant="body1" paragraph>
            {movie.description}
          </Typography>
          <Divider sx={{ my: 3 }} />
          <Typography variant="h6" gutterBottom>
            Genre
          </Typography>
          <Box sx={{ display: 'flex', gap: 1, mb: 3 }}>
            {movie.genre.map((genre) => (
              <Chip key={genre} label={genre} color="primary" />
            ))}
          </Box>
          <Typography variant="h6" gutterBottom>
            Release Date
          </Typography>
          <Typography variant="body1" paragraph>
            {new Date(movie.releaseDate).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            })}
          </Typography>
          <Typography variant="h6" gutterBottom>
            Price
          </Typography>
          <Typography variant="h5" color="primary" gutterBottom>
            ₹{movie.price.toFixed(0)}
          </Typography>
          <Button
            variant="contained"
            color="primary"
            size="large"
            sx={{ mt: 4 }}
            onClick={() => navigate(`/booking/${movie.id}`)}
          >
            Book Now
          </Button>
        </Box>
      </Box>

      {/* Comments Section */}
      <Box sx={{ mt: 8 }}>
        <Typography variant="h4" gutterBottom>
          Reviews & Comments
        </Typography>
        
        {/* Add Comment Form - Only shown when user is logged in */}
        {isAuthenticated ? (
          <Paper sx={{ p: 3, mb: 4 }}>
            <Typography variant="h6" gutterBottom>
              Write a Review
            </Typography>
            <Box sx={{ mb: 2 }}>
              <Typography component="legend">Your Rating</Typography>
              <Rating
                value={newRating}
                onChange={(_, value) => setNewRating(value)}
                precision={0.5}
              />
            </Box>
            <TextField
              fullWidth
              multiline
              rows={4}
              variant="outlined"
              placeholder="Write your review here..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              sx={{ mb: 2 }}
            />
            <Button
              variant="contained"
              color="primary"
              onClick={handleAddComment}
              disabled={!newComment || !newRating}
            >
              Post Review
            </Button>
          </Paper>
        ) : (
          <Paper sx={{ p: 3, mb: 4, textAlign: 'center' }}>
            <Typography variant="body1" gutterBottom>
              Please log in to write a review
            </Typography>
            <Button
              variant="contained"
              color="primary"
              onClick={() => navigate('/login')}
            >
              Log In
            </Button>
          </Paper>
        )}

        {/* Comments List */}
        <List>
          {movie.comments.map((comment) => (
            <Paper key={comment.id} sx={{ mb: 2, p: 2 }}>
              <ListItem alignItems="flex-start">
                <ListItemAvatar>
                  <Avatar>{comment.userName[0]}</Avatar>
                </ListItemAvatar>
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                      <Typography variant="subtitle1" component="span">
                        {comment.userName}
                      </Typography>
                      <Rating value={comment.rating / 2} readOnly size="small" />
                    </Box>
                  }
                  secondary={
                    <>
                      <Typography
                        component="span"
                        variant="body2"
                        color="text.primary"
                        sx={{ display: 'block', mb: 1 }}
                      >
                        {new Date(comment.date).toLocaleDateString('en-US', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </Typography>
                      <Typography variant="body1">
                        {comment.text}
                      </Typography>
                    </>
                  }
                />
              </ListItem>
            </Paper>
          ))}
        </List>
      </Box>
    </Container>
  );
};

export default MovieDetails; 