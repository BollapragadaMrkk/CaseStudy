import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Typography,
  Box,
  Paper,
  Button,
  TextField,
  Stepper,
  Step,
  StepLabel,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
} from '@mui/material';

const steps = ['Select Seats', 'Personal Details', 'Payment'];

const Booking = () => {
  const { movieId } = useParams();
  const navigate = useNavigate();
  const [activeStep, setActiveStep] = useState(0);
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [personalDetails, setPersonalDetails] = useState({
    name: '',
    email: '',
    phone: '',
  });
  const [paymentMethod, setPaymentMethod] = useState('credit');

  useEffect(() => {
    if (!movieId) {
      navigate('/movies');
    }
  }, [movieId, navigate]);

  const handleNext = () => {
    if (activeStep === steps.length - 1) {
      // Handle booking completion
      console.log('Booking completed for movie:', movieId);
      navigate('/movies');
    } else {
      setActiveStep((prevStep) => prevStep + 1);
    }
  };

  const handleBack = () => {
    setActiveStep((prevStep) => prevStep - 1);
  };

  const handleSeatSelection = (seatId: string) => {
    setSelectedSeats((prev) =>
      prev.includes(seatId)
        ? prev.filter((id) => id !== seatId)
        : [...prev, seatId]
    );
  };

  const handlePersonalDetailsChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPersonalDetails((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const renderStepContent = (step: number) => {
    switch (step) {
      case 0:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Select Your Seats
            </Typography>
            <Box sx={{ 
              display: 'grid', 
              gridTemplateColumns: 'repeat(8, 1fr)',
              gap: 2
            }}>
              {Array.from({ length: 40 }, (_, i) => (
                <Paper
                  key={i}
                  sx={{
                    p: 2,
                    textAlign: 'center',
                    cursor: 'pointer',
                    bgcolor: selectedSeats.includes(`seat-${i}`)
                      ? 'primary.main'
                      : 'background.paper',
                    color: selectedSeats.includes(`seat-${i}`)
                      ? 'white'
                      : 'text.primary',
                    '&:hover': {
                      bgcolor: selectedSeats.includes(`seat-${i}`)
                        ? 'primary.dark'
                        : 'action.hover',
                    },
                  }}
                  onClick={() => handleSeatSelection(`seat-${i}`)}
                >
                  {i + 1}
                </Paper>
              ))}
            </Box>
          </Box>
        );

      case 1:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Personal Details
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              <TextField
                required
                fullWidth
                label="Full Name"
                name="name"
                value={personalDetails.name}
                onChange={handlePersonalDetailsChange}
              />
              <TextField
                required
                fullWidth
                label="Email"
                name="email"
                type="email"
                value={personalDetails.email}
                onChange={handlePersonalDetailsChange}
              />
              <TextField
                required
                fullWidth
                label="Phone Number"
                name="phone"
                value={personalDetails.phone}
                onChange={handlePersonalDetailsChange}
              />
            </Box>
          </Box>
        );

      case 2:
        return (
          <Box>
            <Typography variant="h6" gutterBottom>
              Payment Method
            </Typography>
            <FormControl component="fieldset">
              <FormLabel component="legend">Select Payment Method</FormLabel>
              <RadioGroup
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
              >
                <FormControlLabel
                  value="credit"
                  control={<Radio />}
                  label="Credit Card"
                />
                <FormControlLabel
                  value="debit"
                  control={<Radio />}
                  label="Debit Card"
                />
                <FormControlLabel
                  value="upi"
                  control={<Radio />}
                  label="UPI"
                />
              </RadioGroup>
            </FormControl>
          </Box>
        );

      default:
        return null;
    }
  };

  return (
    <Container maxWidth="md" sx={{ py: 8 }}>
      <Paper sx={{ p: 4 }}>
        <Typography variant="h4" component="h1" gutterBottom>
          Book Your Tickets
        </Typography>
        <Stepper activeStep={activeStep} sx={{ mb: 4 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        {renderStepContent(activeStep)}
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4 }}>
          <Button
            disabled={activeStep === 0}
            onClick={handleBack}
            variant="outlined"
          >
            Back
          </Button>
          <Button
            variant="contained"
            onClick={handleNext}
            disabled={
              (activeStep === 0 && selectedSeats.length === 0) ||
              (activeStep === 1 &&
                (!personalDetails.name ||
                  !personalDetails.email ||
                  !personalDetails.phone))
            }
          >
            {activeStep === steps.length - 1 ? 'Complete Booking' : 'Next'}
          </Button>
        </Box>
      </Paper>
    </Container>
  );
};

export default Booking; 