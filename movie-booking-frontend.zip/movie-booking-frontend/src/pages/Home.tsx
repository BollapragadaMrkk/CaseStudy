import { Container, Typography, Box, Button, Card, CardContent, CardMedia, Rating, Chip } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { movies } from '../data/movies';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import StarIcon from '@mui/icons-material/Star';

const Home = () => {
  const navigate = useNavigate();

  return (
    <Box>
      {/* Hero Section with Background Image */}
      <Box
        sx={{
          position: 'relative',
          height: '80vh',
          display: 'flex',
          alignItems: 'center',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundImage: 'url(https://m.media-amazon.com/images/M/MV5BYzE5MjY1ZDgtMTkyNC00MTMyLThhMjAtZGI5OTE1NzFlZGJjXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_.jpg)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            filter: 'brightness(0.3)',
            zIndex: 1,
          },
        }}
      >
        <Container maxWidth="md" sx={{ position: 'relative', zIndex: 2, textAlign: 'center' }}>
          <Typography 
            variant="h1" 
            component="h1" 
            gutterBottom
            sx={{
              color: 'white',
              fontSize: { xs: '2.5rem', md: '4rem' },
              fontWeight: 'bold',
              textShadow: '2px 2px 4px rgba(0,0,0,0.5)',
              mb: 2
            }}
          >
            Welcome to Movie Magic
          </Typography>
          <Typography 
            variant="h5" 
            component="h2" 
            gutterBottom
            sx={{
              color: 'white',
              mb: 4,
              textShadow: '1px 1px 2px rgba(0,0,0,0.5)',
              opacity: 0.9
            }}
          >
            Experience the best of Marvel Cinematic Universe
          </Typography>
          <Button
            variant="contained"
            color="primary"
            size="large"
            onClick={() => navigate('/movies')}
            startIcon={<PlayArrowIcon />}
            sx={{ 
              px: 4,
              py: 1.5,
              fontSize: '1.2rem',
              backgroundColor: '#e50914',
              '&:hover': {
                backgroundColor: '#f40612',
                transform: 'scale(1.05)',
                boxShadow: '0 6px 20px rgba(229, 9, 20, 0.3)',
              },
              transition: 'all 0.3s ease-in-out'
            }}
          >
            Book Now
          </Button>
        </Container>
      </Box>

      {/* Featured Movies Section */}
      <Container maxWidth="lg" sx={{ py: 8 }}>
        <Typography 
          variant="h3" 
          component="h2" 
          gutterBottom
          sx={{
            textAlign: 'center',
            mb: 6,
            fontWeight: 'bold',
            background: 'linear-gradient(45deg, #1a237e, #0d47a1)',
            backgroundClip: 'text',
            textFillColor: 'transparent',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent'
          }}
        >
          Featured Movies
        </Typography>
        <Box sx={{ 
          display: 'grid', 
          gridTemplateColumns: {
            xs: '1fr',
            sm: 'repeat(2, 1fr)',
            md: 'repeat(3, 1fr)'
          },
          gap: 4
        }}>
          {movies.map((movie) => (
            <Card
              key={movie.id}
              sx={{
                height: '100%',
                display: 'flex',
                flexDirection: 'column',
                cursor: 'pointer',
                transition: 'all 0.3s ease-in-out',
                '&:hover': {
                  transform: 'translateY(-8px)',
                  boxShadow: '0 12px 20px rgba(0,0,0,0.2)',
                  '& .MuiCardMedia-root': {
                    transform: 'scale(1.05)',
                  }
                },
                overflow: 'hidden'
              }}
              onClick={() => navigate(`/movies/${movie.id}`)}
            >
              <Box sx={{ position: 'relative', overflow: 'hidden' }}>
                <CardMedia
                  component="img"
                  height="450"
                  image={movie.posterUrl}
                  alt={movie.title}
                  sx={{
                    transition: 'transform 0.3s ease-in-out',
                  }}
                />
                <Box
                  sx={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    background: 'linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,0.8) 100%)',
                    opacity: 0,
                    transition: 'opacity 0.3s ease-in-out',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    '&:hover': {
                      opacity: 1,
                    }
                  }}
                >
                  <Button
                    variant="contained"
                    color="primary"
                    sx={{
                      backgroundColor: '#e50914',
                      '&:hover': {
                        backgroundColor: '#f40612',
                      }
                    }}
                  >
                    Book Now
                  </Button>
                </Box>
              </Box>
              <CardContent sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
                <Typography gutterBottom variant="h5" component="h2" sx={{ fontWeight: 'bold' }}>
                  {movie.title}
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <Rating 
                    value={movie.rating / 2} 
                    readOnly 
                    precision={0.5}
                    icon={<StarIcon sx={{ color: '#ffd700' }} />}
                  />
                  <Typography variant="body2" color="text.secondary" sx={{ ml: 1 }}>
                    {movie.rating}/10
                  </Typography>
                </Box>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mb: 2 }}>
                  {movie.genre.map((genre) => (
                    <Chip
                      key={genre}
                      label={genre}
                      size="small"
                      sx={{
                        backgroundColor: 'rgba(25, 118, 210, 0.1)',
                        color: '#1976d2',
                        '&:hover': {
                          backgroundColor: 'rgba(25, 118, 210, 0.2)',
                        }
                      }}
                    />
                  ))}
                </Box>
                <Typography 
                  variant="body2" 
                  color="text.secondary"
                  sx={{
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    display: '-webkit-box',
                    WebkitLineClamp: 3,
                    WebkitBoxOrient: 'vertical',
                    mb: 2
                  }}
                >
                  {movie.description}
                </Typography>
                <Typography 
                  variant="h6" 
                  color="primary"
                  sx={{ 
                    mt: 'auto',
                    fontWeight: 'bold',
                    color: '#e50914'
                  }}
                >
                  ₹{movie.price.toFixed(0)}
                </Typography>
              </CardContent>
            </Card>
          ))}
        </Box>
      </Container>
    </Box>
  );
};

export default Home; 