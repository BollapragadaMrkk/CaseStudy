export interface Comment {
  id: number;
  userId: number;
  userName: string;
  text: string;
  rating: number;
  date: string;
}

export interface Movie {
  id: number;
  title: string;
  description: string;
  releaseDate: string;
  duration: number; // in minutes
  genre: string[];
  rating: number;
  posterUrl: string;
  price: number;
  comments: Comment[];
}

export interface MovieState {
  movies: Movie[];
  selectedMovie: Movie | null;
  loading: boolean;
  error: string | null;
} 