import { Movie } from '../types/movie';

export const movies: Movie[] = [
  {
    id: 1,
    title: 'Avengers: Endgame',
    description: 'After the devastating events of Avengers: Infinity War, the universe is in ruins. With the help of remaining allies, the Avengers assemble once more in order to reverse Thanos\' actions and restore balance to the universe.',
    releaseDate: '2019-04-26',
    duration: 181,
    genre: ['Action', 'Adventure', 'Drama'],
    rating: 8.4,
    posterUrl: 'https://m.media-amazon.com/images/M/MV5BMTc5MDE2ODcwNV5BMl5BanBnXkFtZTgwMzI2NzQ2NzM@._V1_.jpg',
    price: 250,
    comments: [
      {
        id: 1,
        userId: 1,
        userName: 'John Doe',
        text: 'An epic conclusion to the Infinity Saga. The emotional moments were perfectly executed.',
        rating: 9,
        date: '2024-03-15'
      },
      {
        id: 2,
        userId: 2,
        userName: 'Jane Smith',
        text: 'The final battle scene was absolutely breathtaking!',
        rating: 8,
        date: '2024-03-14'
      }
    ]
  },
  {
    id: 2,
    title: 'Spider-Man: No Way Home',
    description: 'With Spider-Man\'s identity now revealed, Peter asks Doctor Strange for help. When a spell goes wrong, dangerous foes from other worlds start to appear, forcing Peter to discover what it truly means to be Spider-Man.',
    releaseDate: '2021-12-17',
    duration: 148,
    genre: ['Action', 'Adventure', 'Fantasy'],
    rating: 8.2,
    posterUrl: 'https://m.media-amazon.com/images/M/MV5BZWMyYzFjYTYtNTRjYi00OGExLWE2YzgtOGRmYjAxZTU3NzBiXkEyXkFqcGdeQXVyMzQ0MzA0NTM@._V1_.jpg',
    price: 230,
    comments: [
      {
        id: 3,
        userId: 3,
        userName: 'Mike Johnson',
        text: 'The multiverse concept was handled brilliantly. Loved seeing the old villains!',
        rating: 9,
        date: '2024-03-13'
      }
    ]
  },
  {
    id: 3,
    title: 'Black Panther',
    description: 'T\'Challa, heir to the hidden but advanced kingdom of Wakanda, must step forward to lead his people into a new future and must confront a challenger from his country\'s past.',
    releaseDate: '2018-02-16',
    duration: 134,
    genre: ['Action', 'Adventure', 'Drama'],
    rating: 7.3,
    posterUrl: 'https://m.media-amazon.com/images/M/MV5BMTg1MTY2MjYzNV5BMl5BanBnXkFtZTgwMTc4NTMwNDI@._V1_.jpg',
    price: 220,
    comments: [
      {
        id: 4,
        userId: 4,
        userName: 'Sarah Wilson',
        text: 'Chadwick Boseman\'s performance was outstanding. A true masterpiece.',
        rating: 9,
        date: '2024-03-12'
      }
    ]
  },
  {
    id: 4,
    title: 'Guardians of the Galaxy',
    description: 'A group of intergalactic criminals must pull together to stop a fanatical warrior with plans to purge the universe.',
    releaseDate: '2014-08-01',
    duration: 121,
    genre: ['Action', 'Adventure', 'Comedy'],
    rating: 8.0,
    posterUrl: 'https://m.media-amazon.com/images/M/MV5BMTAwMjU5OTgxNjZeQTJeQWpwZ15BbWU4MDUxNDYxODEx._V1_.jpg',
    price: 210,
    comments: [
      {
        id: 5,
        userId: 5,
        userName: 'David Brown',
        text: 'The soundtrack is amazing! Perfect blend of action and humor.',
        rating: 8,
        date: '2024-03-11'
      }
    ]
  },
  {
    id: 5,
    title: 'Doctor Strange',
    description: 'While on a journey of physical and spiritual healing, a brilliant neurosurgeon is drawn into the world of the mystic arts.',
    releaseDate: '2016-11-04',
    duration: 115,
    genre: ['Action', 'Adventure', 'Fantasy'],
    rating: 7.5,
    posterUrl: 'https://m.media-amazon.com/images/M/MV5BNjgwNzAzNjk1Nl5BMl5BanBnXkFtZTgwMzQ2NjI1OTE@._V1_.jpg',
    price: 200,
    comments: [
      {
        id: 6,
        userId: 6,
        userName: 'Emily Davis',
        text: 'The visual effects are mind-bending! Benedict Cumberbatch was perfect for the role.',
        rating: 8,
        date: '2024-03-10'
      }
    ]
  },
  {
    id: 6,
    title: 'Thor: Ragnarok',
    description: 'Imprisoned on the planet Sakaar, Thor must race against time to return to Asgard and stop Ragnarök, the destruction of his world, at the hands of the powerful and ruthless villain Hela.',
    releaseDate: '2017-11-03',
    duration: 130,
    genre: ['Action', 'Adventure', 'Comedy'],
    rating: 7.9,
    posterUrl: 'https://m.media-amazon.com/images/M/MV5BMjMyNDkzMzI1OF5BMl5BanBnXkFtZTgwODcxODg5MjI@._V1_.jpg',
    price: 215,
    comments: [
      {
        id: 7,
        userId: 7,
        userName: 'Chris Evans',
        text: 'Taika Waititi brought a fresh and hilarious take to the Thor franchise!',
        rating: 9,
        date: '2024-03-09'
      }
    ]
  }
]; 